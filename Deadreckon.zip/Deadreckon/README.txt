To run the code/adjust parameters:

In puTTY, cd into the file directory. The numbers that change in the states dictate how many seconds the sub will do a move.

To change what each state does, scroll down to the bottom and edit the pwm values.

P.S.: Dont be an idiot :D