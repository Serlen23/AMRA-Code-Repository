# Test how many seconds is 360 rotation
import time
from pymavlink import mavutil

# Wait for server connection
def wait_conn(master):
    msg = None
    while not msg:
        master.mav.ping_send(
            time.time(), # Unix time
            0, # Ping number
            0, # Request ping of all systems
            0 # Request ping of all components
        )
        msg = master.recv_match()
        time.sleep(0.5)


master = mavutil.mavlink_connection('udpout:0.0.0.0:9000')
wait_conn(master)

print("Connection secured!")

# arm
master.mav.command_long_send(
1, # autopilot system id
1, # autopilot component id
400, # command id, ARM/DISARM
0, # confirmation
1, # arm!
0,0,0,0,0,0 # unused parameters for this command
)
time.sleep(1)

fullTurnSeconds = 3.4

def degreesToSeconds(degrees):
    return (degrees/360 * fullTurnSeconds)



# Times for how long each state should be (seconds)
states = [degreesToSeconds(360), degreesToSeconds(0)]

# Offset times to one another and offset by time.time()
states[0] += time.time()
for i in range(1, len(states)):
    states[i] += states[i-1]

try:
    # Turn right 360
    while time.time() < states[0]:
        print("Turn 1")
        master.mav.manual_control_send(
            master.target_system, # system
            0, # x [-1000 and 1000]
            0, # y [-1000 and 1000] MOVE FORWARD HALF SPEED
            500, # z [0 and 1000] 500 means no output
            800, # r [-1000 and 1000]
            0) # button args
    while time.time() < states[1]:
        print("Turn 2")
        master.mav.manual_control_send(
            master.target_system, # system
            0, # x [-1000 and 1000]
            0, # y [-1000 and 1000] MOVE FORWARD HALF SPEED
            500, # z [0 and 1000] 500 means no output
            -800, # r [-1000 and 1000]
            0) # button args
finally:
    print("Done")
