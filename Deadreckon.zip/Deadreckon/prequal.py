import time
from pymavlink import mavutil


# Wait for server connection
def wait_conn(master):
    msg = None
    while not msg:
        master.mav.ping_send(
            time.time(), # Unix time
            0, # Ping number
            0, # Request ping of all systems
            0 # Request ping of all components
        )
        msg = master.recv_match()
        time.sleep(0.5)


master = mavutil.mavlink_connection('udpout:0.0.0.0:9000')
wait_conn(master)
print("Connection secured!")

# arm
master.mav.command_long_send(
1, # autopilot system id
1, # autopilot component id
400, # command id, ARM/DISARM
0, # confirmation
1, # arm!
0,0,0,0,0,0 # unused parameters for this command
)

# Manually set this. How many seconds it takes for sub to turn at 800 r
fullTurnSeconds = 3.4

#Go forward this amount
equidistantAmt = 1

def degreesToSeconds(degrees):
    return (degrees/360 * fullTurnSeconds)

print("90 sec")
print(degreesToSeconds(90))

#time.sleep(10)


states = [2, # Wait to untether
          20, # Go Down
          50, # Go Forward
          9.5,   # Turn Left
          5,   # Go Forward
          10.50,   # Turn Left
          50]   # Go Forward

def set_rc_channel_pwm(id, pwm=1500):
    """ Set RC channel pwm value
    Args:
        id (TYPE): Channel ID
        pwm (int, optional): Channel pwm value 1100-1900
    """
    if id < 1:
        print("Channel does not exist.")
        return

    # We only have 8 channels
    #http://mavlink.org/messages/common#RC_CHANNELS_OVERRIDE
    if id < 9:
        rc_channel_values = [65535 for _ in range(8)]
        rc_channel_values[id - 1] = pwm
        master.mav.rc_channels_override_send(
            master.target_system,                # target_system
            master.target_component,             # target_component
            *rc_channel_values)                  # RC channel list, in microseconds.


# Offset times to one another and offset by time.time()
states[0] += time.time()
for i in range(1, len(states)):
    states[i] += states[i-1]

def move_forward():
    master.mav.manual_control_send(
            master.target_system, # system
            850, # x [-1000 and 1000]
            0, # y [-1000 and 1000] MOVE FORWARD HALF SPEED
            500, # z [0 and 1000] 500 means no output
            0, # r [-1000 and 1000]
            0) # button args

try:
    # Wait while being unplugged
    while time.time() < states[0]:
	master.mav.manual_control_send(
            master.target_system, # system
            0, # x [-1000 and 1000]
            0, # y [-1000 and 1000] MOVE FORWARD HALF SPEED
            500, # z [0 and 1000] 500 means no output
            0, # r [-1000 and 1000]
            0) # button args
    # Go Down
    while time.time() < states[1]:
        master.mav.manual_control_send(
            master.target_system, # system
            0, # x [-1000 and 1000]
            0, # y [-1000 and 1000] MOVE FORWARD HALF SPEED
            100, # z [0 and 1000] 500 means no output
            0, # r [-1000 and 1000]
            0) # button args
    # Go Forward
    while time.time() < states[2]:
	master.mav.manual_control_send(
            master.target_system, # system
            600, # x [-1000 and 1000]
            0, # y [-1000 and 1000] MOVE FORWARD HALF SPEED
            500, # z [0 and 1000] 500 means no output
            0, # r [-1000 and 1000]
            0) # button args
    #Turn Left
    while time.time() < states[3]:
	master.mav.manual_control_send(
            master.target_system, # system
            0, # x [-1000 and 1000]
            0, # y [-1000 and 1000] MOVE FORWARD HALF SPEED
            500, # z [0 and 1000] 500 means no output
            -600, # r [-1000 and 1000]
            0) # button args

    # Go Straight
    while time.time() < states[4]:
	master.mav.manual_control_send(
            master.target_system, # system
            600, # x [-1000 and 1000]
            0, # y [-1000 and 1000] MOVE FORWARD HALF SPEED
            500, # z [0 and 1000] 500 means no output
            0, # r [-1000 and 1000]
            0) # button args


    # Turn Left
    while time.time() < states[5]:
	master.mav.manual_control_send(
            master.target_system, # system
            0, # x [-1000 and 1000]
            0, # y [-1000 and 1000] MOVE FORWARD HALF SPEED
            500, # z [0 and 1000] 500 means no output
            -600, # r [-1000 and 1000]
            0) # button args

    # Go Straight
    while time.time() < states[6]:
        master.mav.manual_control_send(
            master.target_system, # system
            600, # x [-1000 and 1000]
            0, # y [-1000 and 1000] MOVE FORWARD HALF SPEED
            500, # z [0 and 1000] 500 means no output
            0, # r [-1000 and 1000]
            0) # button args

finally:
    print("Over")
